title: 我在 GitHub 上的开源项目
date: '2019-10-26 17:43:12'
updated: '2019-10-26 17:43:12'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [yoxin](https://github.com/zentoLu/yoxin) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zentoLu/yoxin/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/zentoLu/yoxin/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zentoLu/yoxin/network/members "分叉数")</span>

echats project



---

### 2. [myReactKit](https://github.com/zentoLu/myReactKit) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zentoLu/myReactKit/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zentoLu/myReactKit/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zentoLu/myReactKit/network/members "分叉数")</span>

a quick start kit with create-react-app --typescript + react-router + materialUI + axios + mobx



---

### 3. [myBlog](https://github.com/zentoLu/myBlog) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zentoLu/myBlog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zentoLu/myBlog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zentoLu/myBlog/network/members "分叉数")</span>





---

### 4. [ai](https://github.com/zentoLu/ai) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zentoLu/ai/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zentoLu/ai/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zentoLu/ai/network/members "分叉数")</span>

ai



---

### 5. [newest-react-scallfold](https://github.com/zentoLu/newest-react-scallfold) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zentoLu/newest-react-scallfold/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zentoLu/newest-react-scallfold/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zentoLu/newest-react-scallfold/network/members "分叉数")</span>





---

### 6. [hukou](https://github.com/zentoLu/hukou) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zentoLu/hukou/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zentoLu/hukou/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zentoLu/hukou/network/members "分叉数")</span>

simple website



---

### 7. [mm](https://github.com/zentoLu/mm) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zentoLu/mm/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zentoLu/mm/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zentoLu/mm/network/members "分叉数")</span>





---

### 8. [imooc-learning](https://github.com/zentoLu/imooc-learning) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zentoLu/imooc-learning/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zentoLu/imooc-learning/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zentoLu/imooc-learning/network/members "分叉数")</span>





---

### 9. [yunkong](https://github.com/zentoLu/yunkong) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zentoLu/yunkong/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zentoLu/yunkong/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zentoLu/yunkong/network/members "分叉数")</span>

big data, cloud phones



---

### 10. [resume](https://github.com/zentoLu/resume) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/zentoLu/resume/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/zentoLu/resume/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zentoLu/resume/network/members "分叉数")</span>

new resume for 2017

